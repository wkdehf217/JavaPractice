# Post

![diagram](https://github.com/wkdehf217/Post/assets/45251507/5517ad80-7ad3-4659-9c5f-e328b1b3a212)

![erd](https://github.com/wkdehf217/Post/assets/45251507/6d93ca8e-c0d4-406d-b64c-3d0b741154c2)
